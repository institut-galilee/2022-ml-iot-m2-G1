package com.example.mwenweou

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Hand : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_hand)
    }
}