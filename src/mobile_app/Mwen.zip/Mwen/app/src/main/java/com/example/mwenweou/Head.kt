package com.example.mwenweou

import android.content.Context
import android.content.pm.PackageManager
import android.graphics.ImageFormat
import android.hardware.camera2.*
import android.hardware.camera2.CameraDevice
import android.media.ImageReader
import android.os.Bundle
import android.view.SurfaceView
import androidx.appcompat.app.AppCompatActivity
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CameraAccessException

import androidx.core.app.ActivityCompat

import android.graphics.SurfaceTexture

import android.hardware.camera2.CameraCharacteristics

import android.hardware.camera2.params.StreamConfigurationMap
import java.util.jar.Manifest


class Head : AppCompatActivity() {
    protected var cameraDevice: CameraDevice? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_head)
    }

}